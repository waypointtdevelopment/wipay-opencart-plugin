<?php
// Heading
$_['heading_title']		 = 'Wipay Voucher';

// Text
$_['text_extension']     = 'Extensions';
$_['text_success']		 = 'Success: You have modified the Wipay Voucher extenstion details!';
$_['text_edit']          = 'Edit Wipay Voucher';
$_['text_pp_payflow']	 = '<a target="_BLANK" href="https://www.paypal.com/uk/mrb/pal=V4T754QB63XXL"><img src="view/image/payment/paypal.png" alt="PayPal Payflow Pro" title="PayPal Payflow Pro" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization'] = 'Authorization';
$_['text_sale']			 = 'Sale';

// Entry
$_['entry_developer_id']           = 'Developer ID';
$_['entry_test']		           = 'Test Mode';
$_['entry_total']		           = 'Minimum Total';
$_['entry_absorb_fee']             = 'Absorb Transaction Fee';
$_['entry_order_status_success']   = 'Order Status on Success';
$_['entry_order_status_failure']   = 'Order Status on Failure';
$_['entry_geo_zone']	           = 'Geo Zone';
$_['entry_status']		           = 'Status';
$_['entry_sort_order']	           = 'Sort Order';

// Help
$_['help_developer_id']	 = 'Your developer ID that was created when you created your Wipay account';
$_['help_test']			 = 'Use the live or testing (sandbox) gateway server to process transactions?';
$_['help_absorb_fee']	 = 'The customer will NOT pay an additional TTD$5.00 transaction fee to load money into your wipay account';
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active';

// Error
$_['error_permission']	 = 'Warning: You do not have permission to modify payment Wipay Credit!';
$_['error_developer_id'] = 'Developer ID Required!';