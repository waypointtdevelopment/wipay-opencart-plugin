<?php
$_['text_title']     = 'Wipay Voucher';
$_['button_confirm'] = 'Confirm Order';
$_['text_success']	 = 'Payment has been successful.';
$_['text_fail']	     = 'Payment has been cancelled.';
$_['text_valid']	 = 'Payment has been cancelled. Validation failed.';
$_['entry_voucher']	 = 'Voucher code:  ';
$_['text_voucher']	 = 'Enter 12-digit Wipay voucher code here';
$_['button_verify']	 = 'Verfiy Voucher Code';
?>
