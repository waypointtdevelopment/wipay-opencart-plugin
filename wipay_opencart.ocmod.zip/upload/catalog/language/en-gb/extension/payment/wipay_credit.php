<?php
$_['text_title']     = 'Wipay Credit';
$_['button_confirm'] = 'Confirm Order';
$_['text_success']	 = 'Payment has been successful.';
$_['text_fail']	     = 'Payment has been cancelled.';
$_['text_valid']	 = 'Payment has been cancelled. Validation failed.';
?>
