<?php
class ControllerExtensionPaymentWipayVoucher extends Controller {
	
	public function index() {
		//**Load language file and setup the data for the buttons
		$this->language->load('extension/payment/wipay_voucher');
		
		$data['action'] = $this->url->link('extension/payment/wipay_voucher/voucherPay', '', 'SSL');
		$data['button_confirm'] = $this->language->get('button_confirm');

		return $this->load->view('extension/payment/wipay_voucher', $data);
	}
	
	public function voucherCheck(){
		//**Set post data
		$post = [
			'voucher' => $_GET['voucher'],
		];
		
		//**Set gateway url based on admin configuration
		$gateway = '';                                                               
		if(!$this->config->get('payment_wipay_voucher_test')){
			$gateway = 'https://wipayfinancial.com/v1/voucher_check';
		}else{
			$gateway = 'https://sandbox.wipayfinancial.com/v1/voucher_check';
		}
		
		//**Get payment response from gateway
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $gateway);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		curl_close ($ch);
		
		//**Show response for ajax call
		echo $result;
	}
	
	public function voucherPay(){
		//**Load language file and the order information from the user's active session
		$this->language->load('extension/payment/wipay_voucher');
		$this->load->model('checkout/order');                   
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		//**Get TTD exchange rate and calculate the grand total
		$query = $this->db->query("SELECT value from oc_currency where code='TTD'"); 
		$tt_rate = $query->row['value'];
		$tt_total = (float)$order_info['total']*(float)$tt_rate;
		
		//**Set gateway url based on admin configuration
		$gateway = '';                                                               
		if(!$this->config->get('payment_wipay_voucher_test')){
			$gateway = 'https://wipayfinancial.com/v1/voucher_pay';
		}else{
			$gateway = 'https://sandbox.wipayfinancial.com/v1/voucher_pay';
		}
		
		//**Set post data
		$post = [
			'account_number' => $this->config->get('payment_wipay_voucher_developer_id'),
			'details'        => 'This is a voucher payment from an opencart store',
			'total'          => $tt_total,
			'voucher'        => $_POST['voucher_code_input'],
		];
				
		//**Get payment response from gateway
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $gateway);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		curl_close ($ch);	

		//**Redirect based on gateway response
		$obj = json_decode($result);
		if($obj->status=='success'){
			$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('payment_wipay_credit_order_status_success_id'), $obj->msg.'. Transaction id: '.$obj->trxn_id, true);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('checkout/success', '', 'SSL'));
		}else{
			$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('payment_wipay_credit_order_status_fail_id'), $obj->status.': '.$obj->msg, true);
			$this->session->data['error'] = $this->language->get('text_fail');
			$this->response->redirect($this->url->link('checkout/cart', '', 'SSL'));
		} 
	}
}
