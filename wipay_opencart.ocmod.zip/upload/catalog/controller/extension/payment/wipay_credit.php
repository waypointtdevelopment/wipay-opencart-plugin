<?php
class ControllerExtensionPaymentWipayCredit extends Controller {
	
	public function index() {
		//**Load language file and the order information from the user's active session
		$this->language->load('extension/payment/wipay_credit');
		$this->load->model('checkout/order');                   
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		//**Get TTD exchange rate and calculate the grand total based on whether the admin is asorbing the transaction or not
		$query = $this->db->query("SELECT value from oc_currency where code='TTD'"); 
		$tt_rate = $query->row['value'];
		$tt_total = (float)$order_info['total']*(float)$tt_rate;
		$grand_total = null;
		if(!$this->config->get('payment_wipay_credit_absorb_fee')){
			$grand_total = $tt_total + $tt_total * 0.03 + 5;
		}else{
			$grand_total = $tt_total;
		}
		
		//**Set gateway url based on admin configuration
		$gateway = '';                                                               
		if($this->config->get('payment_wipay_credit_test')){
			$gateway = 'https://wipayfinancial.com/v1/gateway';
		}else{
			$gateway = 'https://wipayfinancial.com/v1/gateway_live';
		}
		
		//**Set up the data for the hidden variables which will be used to submit the form to the payment gateway URL
		$data['action'] = $gateway;
		$data['button_confirm'] = $this->language->get('button_confirm');
		$data['total'] = round($grand_total, 2);
		$data['phone'] = $order_info['telephone'];
		$data['email'] = $order_info['email'];
		$data['name'] = $order_info['payment_firstname'].' '.$order_info['payment_lastname'];
		$data['order_id'] = $this->session->data['order_id'];
		$data['return_url'] = $this->config->get('config_url').'wipay_credit/callback';
		//$this->config->get('config_url').'index.php?route=extension/payment/wipay_credit/callback';
		$data['developer_id'] = $this->config->get('payment_wipay_credit_developer_id');
			
		//echo print_r($order_info);
		//echo round($grand_total, 2).'</br>';
		//echo $gateway;
		return $this->load->view('extension/payment/wipay_credit', $data);
	}
	
	public function callback(){		
		//**Create harsh for validation	
		$merchant_key = $this->config->get('payment_wipay_credit_merchant_key');
		$hash = md5($_GET['order_id'].$_GET['total'].$merchant_key);
		
		//**Load language file and order information from returned order id parameter
		$this->language->load('extension/payment/wipay_credit');
		$this->load->model('checkout/order');                   
		$order_info = $this->model_checkout_order->getOrder($_GET['order_id']);
		
		//**Redirect based on status and validation.
		if($_GET['status'] == 'success')
		{			
			if($hash == $_GET['hash']) 
			{
				$this->model_checkout_order->addOrderHistory($_GET['order_id'], $this->config->get('payment_wipay_credit_order_status_success_id'), rtrim($_GET['reasonDescription'],'.').' at '.$_GET['date'].'. Wipay transaction id: '.$_GET['transaction_id'], true);
				$this->session->data['success'] = $this->language->get('text_success');
				$this->response->redirect($this->url->link('checkout/success', '', 'SSL'));
			}else{
				$this->model_checkout_order->addOrderHistory($_GET['order_id'], $this->config->get('payment_wipay_credit_order_status_fail_id'), rtrim($_GET['reasonDescription'],'.').' at '.$_GET['date'].'. Wipay transaction id: '.$_GET['transaction_id'], true);
				$this->session->data['error'] = $this->language->get('text_valid');
				$this->response->redirect($this->url->link('checkout/cart', '', 'SSL'));
			}
		}else{
			$this->model_checkout_order->addOrderHistory($_GET['order_id'], $this->config->get('payment_wipay_credit_order_status_fail_id'), rtrim($_GET['reasonDescription'],'.').' at '.$_GET['date'].'. Wipay transaction id: '.$_GET['transaction_id'], true);
			$this->session->data['error'] = $this->language->get('text_fail');
			$this->response->redirect($this->url->link('checkout/cart', '', 'SSL'));
		} 
	}
}
