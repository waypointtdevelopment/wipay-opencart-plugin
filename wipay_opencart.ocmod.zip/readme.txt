=== Wipay Checkout Payment Gateway for Opencart 3.0.3.2 ===
Version 1.1
Contributors: Vikash Kumar
Tags: payment gateway, opencart payment gateway
Requires at least: 3.0.3.2
Tested up to: 3.0.3.2
Stable tag: 3.0.3.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

It's a Opencart 3 extension allow clients make payments.

== Description ==
This extension allows customers to make purchases using Wipay's payment gateway using credit card and/or voucher. 
Credit card: When an order is placed, user is redirected to Wipay's secure hosted payment page where only the credit card information is entered.
Voucher: The customer can check the voucher then place an order using a Wipay voucher code.

== Installation ==
1. Upload the module file wipay_opencart.ocmod.zip via Extensions > Extension Installer in the admin panel
2. Activate the module:
	a. On the admin panel select Extensions > Extensions > Choose the extension type > Payments. Scroll down to "Wipay Credit" and "Wipay Voucher" then 
	   click "Install".
	b. Click "Edit" and configure the module settings for Wipay Credit and Wipay Voucher. See the FAQ section for test payment and test order setup.
4. Edit the .htaccess file (necessary for Wipay Credit only):
	a. To show file extensions in your file explorer, select View > Folder Options > View and uncheck "Hide extensions for known file types".
	b. In the opencart install directory, save the ".htaccess.txt" file as ".htaccess" (all file types). 
	c. In the ".htaccess" file, look for the line "RewriteBase /". In the next line insert: 
	   	RewriteRule wipay_credit/callback index.php?route=extension/payment/wipay_credit/callback [QSA]
5. If the base of your store is not TTD, setup your store to show TTD currency:
	a. In the admin panel, select Stores > Configuration > Currencies.
	b. Select "add new" and configure the module settings:
		Currency Title: TT Dollar
		Code: TTD
		Symbol Left: $
		Decimal PLaces: 2
		Value: 6.80
		Status: Enabled

Note: The merchant is responsible for changing the value of the exchange rate which is used to calculate the total to be paid in TTD. If the base store currency is 
TTD, this value is 1 by default.
  	
== Frequently Asked Questions ==
= How do setup and perform a test payment and test order on Wipay Credit? =

* Test values can be found on this link: https://wipaytoday.com/credit-card-documentation/
* On the admin panel, configure the module settings as follows (see step 2 in the installation instructions):
	Developer ID: 1
	Merchant key: 123
	Test Mode: Yes
	Order Status on Success: Complete
	Order Status on Failure: Canceled
	Absorb Transaction Fee: Yes
	Minimum Total: 10
	Sort Order: 1
	Geo Zone: All
	Status: Enabled
* On the Wipay credit card payment page, enter the information as follows:
	Card Number: 4111111111111111	
	Card CVV: 123
	Expiry Month: 01
	Expiry Year: 25
* Verify your purchase on the Sales > Orders page on the admin panel.
Note: To accept live payments, update the Developer ID, Merchant Key, and Test Mode fields accordingly.

= How do setup and perform a test payment and test order on Wipay Voucher? =

* Test values can be found on this link: https://wipaytoday.com/voucher-api-pay/
* On the admin panel, configure the module settings as follows (see step 2 in the installation instructions):
	Developer ID: 4630
	Test Mode: Yes
	Order Status on Success: Complete
	Order Status on Failure: Canceled
	Minimum Total: 0.01
	Sort Order: 2
	Geo Zone: All
	Status: Enabled
* On the checkout page, enter the information as follows:
	Voucher Code: uyr8vmap230t
* Verify your purchase on the Sales > Orders page on the admin panel.
Note: To accept live payments, update the Developer ID and Test Mode fields accordingly.

== Changelog ==
= 1.0 =
* It's first release
= 1.1 =
* Minor bug fix when saving order information to database